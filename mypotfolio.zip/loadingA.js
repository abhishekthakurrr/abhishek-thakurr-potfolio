 // JavaScript to redirect after the animation
  setTimeout(() => {
    window.location.href = "home1.html"; // Replace with your target URL
  }, 1000);
  
 