  // JavaScript to redirect after the animation
  document.getElementById('svg-logo').addEventListener('animationend', function() {
  
    // Redirect to the next page after the animation ends
    window.location.href = 'home1.html'; // Replace with your next page URL
  });
